# Winter — fresh proxy browser starter

A fresh, sleek white-and-ice-blue browser homepage with a space-inspired background, same-tab proxy navigation, clickable tabs, bookmarks, history, shortcuts, side menu, and dark-mode toggle.

## Run locally
1. Install Node.js 18 or newer.
2. Open a terminal in this folder.
3. Run `npm install`
4. Run `npm start`
5. Open `http://localhost:3000`

## Deploy
This project needs a Node.js host. Do not use Netlify Drop as a static upload: it cannot run the proxy server.
- Push the folder contents to a GitHub repository.
- In Render, create a Blueprint from that repository (it uses `render.yaml`).
- Open the `onrender.com` URL Render provides.

## Notes
This is a new starter and has not been tested against a live deployment. Proxy frameworks and sites can change or block access; the UI working locally does not guarantee every destination will proxy successfully. Use responsibly and follow your host's acceptable-use rules.
