(() => {
  const $ = (selector) => document.querySelector(selector);
  const tabsEl = $("#tabs");
  const contentView = $("#contentView");
  const homeView = $("#homeView");
  const addressInput = $("#addressInput");
  const searchInput = $("#searchInput");
  const toast = $("#toast");
  const STORAGE = { bookmarks: "winter.bookmarks.v1", history: "winter.history.v1" };
  let tabs = [];
  let activeId = 1;
  let nextId = 2;
  let toastTimer;

  const read = (key, fallback = []) => {
    try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback)); }
    catch { return fallback; }
  };
  const save = (key, value) => localStorage.setItem(key, JSON.stringify(value));
  const current = () => tabs.find(t => t.id === activeId);

  function notify(message) {
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
  }

  function normalizeTarget(raw) {
    const value = raw.trim();
    if (!value) return "";
    if (/^https?:\/\//i.test(value)) return value;
    if (/^[\w-]+(\.[\w-]+)+([/?#].*)?$/i.test(value) && !value.includes(" ")) return "https://" + value;
    return "https://www.google.com/search?q=" + encodeURIComponent(value);
  }

  async function go(raw) {
    const target = normalizeTarget(raw);
    if (!target) return;
    if (!("serviceWorker" in navigator) || !window.Ultraviolet) {
      notify("Proxy scripts are still loading. Refresh and try again.");
      return;
    }
    try {
      await navigator.serviceWorker.register("/uv/uv.sw.js", { scope: "/" });
      await navigator.serviceWorker.ready;
      const tab = current();
      if (tab) tab.url = target;
      const history = read(STORAGE.history);
      history.unshift({ title: target.replace(/^https?:\/\//, ""), url: target, time: Date.now() });
      save(STORAGE.history, history.slice(0, 100));
      renderTabs();
      window.location.assign("/service/" + Ultraviolet.codec.xor.encode(target));
    } catch (error) {
      console.error(error);
      notify("Proxy setup failed. Check the server deployment logs.");
    }
  }

  function renderTabs() {
    tabsEl.innerHTML = "";
    tabs.forEach(tab => {
      const el = document.createElement("button");
      el.className = "tab" + (tab.id === activeId ? " selected" : "");
      el.setAttribute("role", "tab");
      el.setAttribute("aria-selected", String(tab.id === activeId));
      const title = document.createElement("span");
      title.className = "tab-title";
      title.textContent = tab.title || "New Tab";
      el.append(title);
      el.addEventListener("click", () => {
        activeId = tab.id;
        if (tab.url && tab.url !== "winter://home") {
          window.location.assign("/service/" + Ultraviolet.codec.xor.encode(tab.url));
        } else showHome();
        renderTabs();
      });
      if (tabs.length > 1) {
        const close = document.createElement("span");
        close.className = "tab-close";
        close.textContent = "×";
        close.title = "Close tab";
        close.addEventListener("click", (event) => {
          event.stopPropagation();
          tabs = tabs.filter(t => t.id !== tab.id);
          if (activeId === tab.id) activeId = tabs[tabs.length - 1].id;
          renderTabs();
          const active = current();
          if (active.url && active.url !== "winter://home") window.location.assign("/service/" + Ultraviolet.codec.xor.encode(active.url));
          else showHome();
        });
        el.append(close);
      }
      tabsEl.append(el);
    });
  }

  function showHome() {
    homeView.hidden = false;
    contentView.hidden = true;
    contentView.innerHTML = "";
    addressInput.value = "";
    searchInput.focus();
    const tab = current();
    if (tab) { tab.url = "winter://home"; tab.title = "New Tab"; }
    renderTabs();
  }

  function openNewTab() {
    const tab = { id: nextId++, title: "New Tab", url: "winter://home" };
    tabs.push(tab);
    activeId = tab.id;
    renderTabs();
    showHome();
  }

  function showList(view) {
    homeView.hidden = true;
    contentView.hidden = false;
    contentView.innerHTML = "";
    const heading = document.createElement("h1");
    heading.className = "list-heading";
    heading.textContent = view === "bookmarks" ? "Bookmarks" : view === "history" ? "Recent history" : "Settings";
    contentView.append(heading);
    if (view === "settings") {
      const p = document.createElement("p");
      p.className = "empty-state";
      p.textContent = "Winter uses a search engine for text searches and Ultraviolet for proxy navigation. Your bookmarks are saved in this browser.";
      contentView.append(p);
      return;
    }
    const items = read(view === "bookmarks" ? STORAGE.bookmarks : STORAGE.history);
    if (!items.length) {
      const p = document.createElement("p");
      p.className = "empty-state";
      p.textContent = view === "bookmarks" ? "No bookmarks yet. Tap ☆ in the address bar to save a page." : "Pages you visit will show up here.";
      contentView.append(p);
      return;
    }
    items.forEach((item, index) => {
      const row = document.createElement("div");
      row.className = "saved-row";
      const open = document.createElement("button");
      open.className = "saved-link";
      open.innerHTML = "";
      const name = document.createElement("strong");
      name.textContent = item.title || item.url;
      const url = document.createElement("span");
      url.textContent = item.url;
      open.append(name, url);
      open.addEventListener("click", () => go(item.url));
      row.append(open);
      if (view === "bookmarks") {
        const remove = document.createElement("button");
        remove.className = "remove-button";
        remove.textContent = "Remove";
        remove.addEventListener("click", () => {
          const bookmarks = read(STORAGE.bookmarks);
          bookmarks.splice(index, 1);
          save(STORAGE.bookmarks, bookmarks);
          showList("bookmarks");
        });
        row.append(remove);
      }
      contentView.append(row);
    });
  }

  $("#searchForm").addEventListener("submit", event => { event.preventDefault(); go(searchInput.value); });
  $("#addressForm").addEventListener("submit", event => { event.preventDefault(); go(addressInput.value); });
  $("#newTab").addEventListener("click", openNewTab);
  $("#backBtn").addEventListener("click", () => history.length > 1 ? history.back() : showHome());
  $("#reloadBtn").addEventListener("click", () => location.reload());
  $("#menuBtn").addEventListener("click", () => notify("Use the side menu for bookmarks, history, and settings."));
  $("#bookmarkCurrent").addEventListener("click", () => {
    const url = addressInput.value.trim() || current()?.url;
    if (!url || url === "winter://home") { notify("Open a website first, then bookmark it."); return; }
    const target = normalizeTarget(url);
    const bookmarks = read(STORAGE.bookmarks);
    if (!bookmarks.some(b => b.url === target)) {
      bookmarks.unshift({ title: target.replace(/^https?:\/\//, ""), url: target });
      save(STORAGE.bookmarks, bookmarks);
      notify("Bookmark saved.");
    } else notify("Already bookmarked.");
  });
  document.querySelectorAll(".nav-item").forEach(button => button.addEventListener("click", () => {
    document.querySelectorAll(".nav-item").forEach(b => b.classList.toggle("active", b === button));
    const view = button.dataset.view;
    if (view === "home") showHome(); else showList(view);
  }));
  $("#themeToggle").addEventListener("click", () => {
    document.body.classList.toggle("dark");
    localStorage.setItem("winter.dark", document.body.classList.contains("dark") ? "1" : "0");
  });
  if (localStorage.getItem("winter.dark") === "1") document.body.classList.add("dark");
  document.querySelectorAll(".shortcut[data-url]").forEach(button => button.addEventListener("click", () => go(button.dataset.url)));
  $("#addShortcut").addEventListener("click", () => $("#addDialog").showModal());
  $("#addBookmarkForm").addEventListener("submit", event => {
    event.preventDefault();
    const name = $("#shortcutName").value.trim();
    const url = normalizeTarget($("#shortcutUrl").value);
    if (!name || !url) return;
    const button = document.createElement("button");
    button.className = "shortcut";
    const icon = document.createElement("span");
    icon.className = "shortcut-icon add";
    icon.textContent = name.slice(0, 1).toUpperCase();
    const label = document.createElement("span");
    label.textContent = name;
    button.append(icon, label);
    button.addEventListener("click", () => go(url));
    $("#shortcuts").insertBefore(button, $("#addShortcut"));
    $("#addDialog").close();
    $("#shortcutName").value = "";
    $("#shortcutUrl").value = "";
  });

  tabs = [{ id: 1, title: "Winter", url: "winter://home" }];
  renderTabs();
  if (!("serviceWorker" in navigator)) notify("Use a modern browser to run Winter.");
})();
