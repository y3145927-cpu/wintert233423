import express from "express";
import { createBareServer } from "@tomphttp/bare-server-node";
import { uvPath } from "@titaniumnetwork-dev/ultraviolet";
import { createServer } from "node:http";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const server = createServer();
const bare = createBareServer("/bare/");

app.get("/health", (_req, res) => res.status(200).send("ok"));
app.use("/uv/", express.static(uvPath));
app.use(express.static(path.join(__dirname, "public")));

server.on("request", (req, res) => {
  if (bare.shouldRoute(req)) {
    bare.routeRequest(req, res);
  } else {
    app(req, res);
  }
});

server.on("upgrade", (req, socket, head) => {
  if (bare.shouldRoute(req)) {
    bare.routeUpgrade(req, socket, head);
  } else {
    socket.end();
  }
});

const port = Number(process.env.PORT || 3000);
server.listen(port, () => console.log(`Winter is running on port ${port}`));
